/* lib/version.h.  Generated from version.h.in by configure.
 *
 * Quagga version
 * Copyright (C) 1997, 1999 Kunihiro Ishiguro
 * 
 * This file is part of GNU Zebra.
 *
 * GNU Zebra is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * GNU Zebra is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GNU Zebra; see the file COPYING.  If not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.  
 */

#ifndef _ZEBRA_VERSION_H
#define _ZEBRA_VERSION_H

#ifdef GIT_VERSION
#include "gitversion.h"
#endif

#ifndef GIT_SUFFIX
#define GIT_SUFFIX ""
#endif
#ifndef GIT_INFO
#define GIT_INFO ""
#endif

#define QUAGGA_PROGNAME   "Quagga"

#define QUAGGA_VERSION     "0.99.25-dev-OPNFV-0.99.24.99-6" GIT_SUFFIX

#define ZEBRA_BUG_ADDRESS "https://bugzilla.quagga.net"

#define QUAGGA_URL "http://www.quagga.net"

#define QUAGGA_COPYRIGHT "Copyright 1996-2005 Kunihiro Ishiguro, et al."

#define QUAGGA_CONFIG_ARGS "--build=x86_64-linux-gnu --prefix=/usr --includedir=${prefix}/include --mandir=${prefix}/share/man --infodir=${prefix}/share/info --sysconfdir=/etc --localstatedir=/var --libexecdir=${prefix}/lib/opnfv-quagga --disable-maintainer-mode --disable-dependency-tracking --enable-exampledir=/usr/share/doc/quagga/examples/ --localstatedir=/var/run/quagga --sbindir=/usr/lib/quagga --sysconfdir=/etc/quagga --enable-vtysh --enable-isisd --enable-pimd --enable-watchquagga --enable-ospf-te --enable-opaque-lsa --enable-multipath=64 --enable-user=quagga --enable-group=quagga --enable-vty-group=quaggavty --enable-configfile-mask=0640 --enable-logfile-mask=0640 --enable-rtadv --enable-gcc-rdynamic --with-libpam --with-zeromq --with-pkg-extra-version=-OPNFV-0.99.24.99-6"

pid_t pid_output (const char *);

#ifndef HAVE_DAEMON
int daemon(int, int);
#endif

#endif /* _ZEBRA_VERSION_H */
